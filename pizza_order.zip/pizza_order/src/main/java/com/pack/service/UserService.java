package com.pack.service;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.UseDAO;
import com.pack.model.Login;
import com.pack.model.pizzaorder;
public class UserService {
	@Autowired
	private UseDAO userdao;
     public void addUser(Login user) {
    	 userdao.login(user); 	   
			}
     public void orderpage(pizzaorder order)
     {
    	 userdao.orderpage(order);
     }
}
