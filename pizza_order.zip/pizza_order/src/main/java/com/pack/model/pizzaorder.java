package com.pack.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Random;
 
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="pizzaorder")
public class pizzaorder {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	  @Column(name="orderId")
	   int orderId;
	 @Column(name="customerId")
		int customerId;
	 @Column(name="totalprice")
		int totalprice;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	
}
