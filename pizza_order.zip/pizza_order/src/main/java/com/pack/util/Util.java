package com.pack.util;
import java.util.HashMap;
public class Util {
	private static HashMap<Integer,String> topping=new HashMap();
	public static HashMap<Integer,String> getToppings(){
		topping.put(30, "capsicum");
		topping.put(50, "mushroom");
		topping.put(70, "jalapeno");
		topping.put(85, "paneer");
		return topping;
	}
	
}