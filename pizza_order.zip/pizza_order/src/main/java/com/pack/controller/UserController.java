package com.pack.controller;
import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Customer;
import com.pack.model.Login;
import com.pack.model.pizzaorder;
import com.pack.service.UserService;
import com.pack.util.Util;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
 
	@RequestMapping("login")
	public String getlogin(Model m)
	{
		
		m.addAttribute("user", new Login());
		return "login";
	}
	@RequestMapping(value="validatepage")
	public String validate(@Valid @ModelAttribute("user")Login u,BindingResult result,Model m)
	{
		 if (result.hasErrors())
			 {
	
			  return "login";
			 }
	 else
	 {
	  return "home";
		}
	}
	HashMap hm=new HashMap();
	@RequestMapping("/Utilcontroller")
	public String getToppings(Model m)
	{
		System.out.println("topping selection");
		hm=Util.getToppings();
		System.out.println("hm"+hm);
		m.addAttribute("pizzaToppings",hm);
		m.addAttribute("Customer", new Customer());
		return "orderpage";
		
	}
	
}
