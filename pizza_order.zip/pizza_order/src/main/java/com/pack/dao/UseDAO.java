package com.pack.dao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import com.pack.model.Login;
import com.pack.model.pizzaorder;

import java.util.*;

public class UseDAO {
	@Autowired
	private	 SessionFactory sessionFactory;
	public String validate(Login user) {
		   
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  
		  session.save(user);
		  //tx.commit();
		  session.close(); 
	        user = null;
		String h = "from Login as u where u.username=:name and u.password=:pwd";
		Query query = session.createQuery(h);
		query.setParameter("name", user.getUsername());
		query.setParameter("pwd", user.getPassword());
		List list=query.getResultList();
		if(list.size()==0) 
			return "login";
			else
				return "orderpage";
}
	public void orderpage(pizzaorder order)
	{
		Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  Random r=new Random();
		  int rand;
		  for(int i=0;i<10;i++)
		  {
			   rand=r.nextInt(100);
			  
		  }
		  
	}
	
	
}
